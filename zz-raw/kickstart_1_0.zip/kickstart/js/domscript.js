function dom_init() {

  $('a.lightbox').lightBox();

}