HTML/CSS/JS-Kickstart
(Mini-framework for quickly getting started with your web frontend development)

Version 1.0 | Release: 2009-06-29
by Gerrit van Aaken (http://praegnanz.de)

No rights reserved.